<template>
  <div id="app">
    <Table :items="items"></Table>
    <infinite-loader id="loader" :height="'2rem'" :color="'red'" :busy="busy" @load="callback"></infinite-loader>
  </div>
</template>

<script>
import Table from './components/Table.vue'
import InfiniteLoader from 'jj-infinite-loader'

export default {
  name: 'app',
  components: {
    InfiniteLoader,
    Table,
  },
  data(){
    return {
      items:['hello','world'],
      busy:false,
    }
  },
  methods:{
    callback(){
      let self = this
      this.busy = true
      setTimeout(() => {
        self.items = [...self.items,'add','item','to','list']
        self.busy = false
        
      }, 200);
    }
  },
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;

}
#loader {
  padding-top: 20px;
}

</style>
