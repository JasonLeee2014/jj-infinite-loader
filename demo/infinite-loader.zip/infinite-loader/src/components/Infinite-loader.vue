<template>
    <div ref="loader" class="loader"></div>
</template>

<style scoped>
.loader {
    height: 100px;
    background-color: antiquewhite;
}
</style>

<script>
export default {
    props:{
        busy:{
            type:Boolean,
        }
    },
    data(){
        return {
            io:'',
        }
    },
    mounted(){
        this.io = new IntersectionObserver((items)=>{
            let loader = items[0]
            if (loader.intersectionRatio > 0) {
                this.io.unobserve(this.$refs.loader)
                this.$emit('load')
            }
        },)

        this.io.observe(this.$refs.loader)
    },
    watch: {
        busy(val){
            if(!val){
                this.io.observe(this.$refs.loader)
            } 
        }
    }
}
</script>


