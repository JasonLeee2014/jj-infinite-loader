<template>
    <ul class="table">
        <Cell v-for="(item,index) in items" :key="index" :title="item"></Cell>
    </ul>
</template>

<style scoped>
.table {
    background-color: white;
    margin: 0;
    padding: 0;
}
</style>

<script>
import Cell from './Cell.vue'

export default {
    components: {
        Cell,
    },
    props:{
        items:{
            type:Array,
            default:()=>{
                return [5,6,7,8]
            },
        }
    },

}
</script>



