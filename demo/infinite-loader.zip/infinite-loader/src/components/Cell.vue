<template>
    <transition name="fade">
        <li class="cell">
            {{title}}
        </li>
    </transition>
</template>

<style scoped>
.cell {
    height: 100px;
    border-bottom: 1px solid gray;
    line-height: 100px;
    list-style: none;
}

.fade-enter {
    opacity: 0;
}

.fade-enter-to {
    opacity: 1;
    transition: all 2s ease;
}
</style>

<script>
export default {
    props:{
        title:{
            type:String,
            default:'title',
        }
    }
}
</script>


